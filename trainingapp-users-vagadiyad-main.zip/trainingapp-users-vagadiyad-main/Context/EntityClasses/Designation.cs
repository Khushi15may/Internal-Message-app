﻿namespace ChatApp.Context.EntityClasses
{
    public class Designation
    {
        public int Id { get; set; }

        public string Role { get; set; }
    }
}
