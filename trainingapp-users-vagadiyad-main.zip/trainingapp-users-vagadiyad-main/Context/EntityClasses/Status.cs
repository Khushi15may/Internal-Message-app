﻿namespace ChatApp.Context.EntityClasses
{
    public class Status
    {
        public int Id { get; set; }
        public string Content { get; set; }
    }
}
