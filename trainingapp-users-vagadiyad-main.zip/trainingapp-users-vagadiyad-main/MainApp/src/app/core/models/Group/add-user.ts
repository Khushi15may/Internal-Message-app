export interface AddUser {
    userName : string,
    groupId : number
}