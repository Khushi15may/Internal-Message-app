export interface GroupMember {
    userName : string
    firstName : string
    lastName : string
    imageUrl : string
    addedAt : Date
}