export interface AdminProfileDTO
{
    firstName: string,
    lastName: string,
    email:string,
    userName: string
    imageUrl? : string,
    designation : string,
    designationId? : number
}
    