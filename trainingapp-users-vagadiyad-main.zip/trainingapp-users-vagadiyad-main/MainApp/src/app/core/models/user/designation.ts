export interface DesignationModel {
    id : number,
    role : string
}