export interface RegistrationModel
{
    firstName: string,
    lastName: string,
    email: string,
    userName: string,
    designationId : number,
    password:string
}
