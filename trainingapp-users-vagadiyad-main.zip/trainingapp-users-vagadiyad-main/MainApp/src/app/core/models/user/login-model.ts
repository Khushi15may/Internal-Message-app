export interface LoginModel
{
    emailAddress: string,
    userName: string,
    password:string
}
